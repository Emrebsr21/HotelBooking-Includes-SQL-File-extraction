﻿namespace projPRG455
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form3));
            this.pictureBoxMin = new System.Windows.Forms.PictureBox();
            this.pictureBoxExit = new System.Windows.Forms.PictureBox();
            this.labelReceiptBelonging = new System.Windows.Forms.Label();
            this.textBoxLastName = new System.Windows.Forms.TextBox();
            this.textBoxFirstName = new System.Windows.Forms.TextBox();
            this.labelCostPerDay = new System.Windows.Forms.Label();
            this.labelTotalCost = new System.Windows.Forms.Label();
            this.textBoxCostPerDay = new System.Windows.Forms.TextBox();
            this.labelTax = new System.Windows.Forms.Label();
            this.textBoxTax = new System.Windows.Forms.TextBox();
            this.textBoxTotalCost = new System.Windows.Forms.TextBox();
            this.labelAccomodationName = new System.Windows.Forms.Label();
            this.labelAccomodationLocation = new System.Windows.Forms.Label();
            this.textBoxAccomodationLocation = new System.Windows.Forms.TextBox();
            this.textBoxAccomodationName = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxMin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxExit)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBoxMin
            // 
            this.pictureBoxMin.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxMin.Image")));
            this.pictureBoxMin.Location = new System.Drawing.Point(431, 16);
            this.pictureBoxMin.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.pictureBoxMin.Name = "pictureBoxMin";
            this.pictureBoxMin.Size = new System.Drawing.Size(30, 48);
            this.pictureBoxMin.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxMin.TabIndex = 4;
            this.pictureBoxMin.TabStop = false;
            // 
            // pictureBoxExit
            // 
            this.pictureBoxExit.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxExit.Image")));
            this.pictureBoxExit.Location = new System.Drawing.Point(472, 16);
            this.pictureBoxExit.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.pictureBoxExit.Name = "pictureBoxExit";
            this.pictureBoxExit.Size = new System.Drawing.Size(34, 48);
            this.pictureBoxExit.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxExit.TabIndex = 3;
            this.pictureBoxExit.TabStop = false;
            // 
            // labelReceiptBelonging
            // 
            this.labelReceiptBelonging.AutoSize = true;
            this.labelReceiptBelonging.Location = new System.Drawing.Point(22, 25);
            this.labelReceiptBelonging.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelReceiptBelonging.Name = "labelReceiptBelonging";
            this.labelReceiptBelonging.Size = new System.Drawing.Size(136, 19);
            this.labelReceiptBelonging.TabIndex = 5;
            this.labelReceiptBelonging.Text = "Recepit Belonging";
            // 
            // textBoxLastName
            // 
            this.textBoxLastName.Location = new System.Drawing.Point(26, 80);
            this.textBoxLastName.Multiline = true;
            this.textBoxLastName.Name = "textBoxLastName";
            this.textBoxLastName.Size = new System.Drawing.Size(152, 27);
            this.textBoxLastName.TabIndex = 7;
            // 
            // textBoxFirstName
            // 
            this.textBoxFirstName.Location = new System.Drawing.Point(26, 47);
            this.textBoxFirstName.Multiline = true;
            this.textBoxFirstName.Name = "textBoxFirstName";
            this.textBoxFirstName.Size = new System.Drawing.Size(152, 27);
            this.textBoxFirstName.TabIndex = 8;
            // 
            // labelCostPerDay
            // 
            this.labelCostPerDay.AutoSize = true;
            this.labelCostPerDay.Location = new System.Drawing.Point(298, 253);
            this.labelCostPerDay.Name = "labelCostPerDay";
            this.labelCostPerDay.Size = new System.Drawing.Size(98, 19);
            this.labelCostPerDay.TabIndex = 9;
            this.labelCostPerDay.Text = "Cost Per Day";
            // 
            // labelTotalCost
            // 
            this.labelTotalCost.AutoSize = true;
            this.labelTotalCost.Location = new System.Drawing.Point(298, 318);
            this.labelTotalCost.Name = "labelTotalCost";
            this.labelTotalCost.Size = new System.Drawing.Size(80, 19);
            this.labelTotalCost.TabIndex = 10;
            this.labelTotalCost.Text = "Total Cost";
            // 
            // textBoxCostPerDay
            // 
            this.textBoxCostPerDay.Location = new System.Drawing.Point(402, 245);
            this.textBoxCostPerDay.Multiline = true;
            this.textBoxCostPerDay.Name = "textBoxCostPerDay";
            this.textBoxCostPerDay.Size = new System.Drawing.Size(84, 27);
            this.textBoxCostPerDay.TabIndex = 11;
            // 
            // labelTax
            // 
            this.labelTax.AutoSize = true;
            this.labelTax.Location = new System.Drawing.Point(298, 285);
            this.labelTax.Name = "labelTax";
            this.labelTax.Size = new System.Drawing.Size(34, 19);
            this.labelTax.TabIndex = 12;
            this.labelTax.Text = "Tax";
            // 
            // textBoxTax
            // 
            this.textBoxTax.Location = new System.Drawing.Point(402, 278);
            this.textBoxTax.Multiline = true;
            this.textBoxTax.Name = "textBoxTax";
            this.textBoxTax.Size = new System.Drawing.Size(84, 27);
            this.textBoxTax.TabIndex = 13;
            // 
            // textBoxTotalCost
            // 
            this.textBoxTotalCost.Location = new System.Drawing.Point(402, 311);
            this.textBoxTotalCost.Multiline = true;
            this.textBoxTotalCost.Name = "textBoxTotalCost";
            this.textBoxTotalCost.Size = new System.Drawing.Size(84, 27);
            this.textBoxTotalCost.TabIndex = 14;
            // 
            // labelAccomodationName
            // 
            this.labelAccomodationName.AutoSize = true;
            this.labelAccomodationName.Location = new System.Drawing.Point(40, 143);
            this.labelAccomodationName.Name = "labelAccomodationName";
            this.labelAccomodationName.Size = new System.Drawing.Size(157, 19);
            this.labelAccomodationName.TabIndex = 15;
            this.labelAccomodationName.Text = "Accomodation Name";
            // 
            // labelAccomodationLocation
            // 
            this.labelAccomodationLocation.AutoSize = true;
            this.labelAccomodationLocation.Location = new System.Drawing.Point(22, 179);
            this.labelAccomodationLocation.Name = "labelAccomodationLocation";
            this.labelAccomodationLocation.Size = new System.Drawing.Size(175, 19);
            this.labelAccomodationLocation.TabIndex = 16;
            this.labelAccomodationLocation.Text = "Accomodation Location";
            // 
            // textBoxAccomodationLocation
            // 
            this.textBoxAccomodationLocation.Location = new System.Drawing.Point(226, 179);
            this.textBoxAccomodationLocation.Multiline = true;
            this.textBoxAccomodationLocation.Name = "textBoxAccomodationLocation";
            this.textBoxAccomodationLocation.Size = new System.Drawing.Size(280, 27);
            this.textBoxAccomodationLocation.TabIndex = 17;
            // 
            // textBoxAccomodationName
            // 
            this.textBoxAccomodationName.Location = new System.Drawing.Point(226, 143);
            this.textBoxAccomodationName.Multiline = true;
            this.textBoxAccomodationName.Name = "textBoxAccomodationName";
            this.textBoxAccomodationName.Size = new System.Drawing.Size(280, 27);
            this.textBoxAccomodationName.TabIndex = 18;
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(521, 369);
            this.ControlBox = false;
            this.Controls.Add(this.textBoxAccomodationName);
            this.Controls.Add(this.textBoxAccomodationLocation);
            this.Controls.Add(this.labelAccomodationLocation);
            this.Controls.Add(this.labelAccomodationName);
            this.Controls.Add(this.textBoxTotalCost);
            this.Controls.Add(this.textBoxTax);
            this.Controls.Add(this.labelTax);
            this.Controls.Add(this.textBoxCostPerDay);
            this.Controls.Add(this.labelTotalCost);
            this.Controls.Add(this.labelCostPerDay);
            this.Controls.Add(this.textBoxFirstName);
            this.Controls.Add(this.textBoxLastName);
            this.Controls.Add(this.labelReceiptBelonging);
            this.Controls.Add(this.pictureBoxMin);
            this.Controls.Add(this.pictureBoxExit);
            this.Font = new System.Drawing.Font("Microsoft Tai Le", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "Form3";
            this.Text = "Form3";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxMin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxExit)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBoxMin;
        private System.Windows.Forms.PictureBox pictureBoxExit;
        private System.Windows.Forms.Label labelReceiptBelonging;
        private System.Windows.Forms.TextBox textBoxLastName;
        private System.Windows.Forms.TextBox textBoxFirstName;
        private System.Windows.Forms.Label labelCostPerDay;
        private System.Windows.Forms.Label labelTotalCost;
        private System.Windows.Forms.TextBox textBoxCostPerDay;
        private System.Windows.Forms.Label labelTax;
        private System.Windows.Forms.TextBox textBoxTax;
        private System.Windows.Forms.TextBox textBoxTotalCost;
        private System.Windows.Forms.Label labelAccomodationName;
        private System.Windows.Forms.Label labelAccomodationLocation;
        private System.Windows.Forms.TextBox textBoxAccomodationLocation;
        private System.Windows.Forms.TextBox textBoxAccomodationName;
    }
}